INTERNET PROGRAMMING LAB — EXPERIMENTS 21–40

Extract this ZIP and open index.html in a modern browser.
All pages are standalone responsive HTML files.
Demo form submissions are stored in browser localStorage on that device only.
No backend server, real payment or email integration is included.
The source brief repeats experiment 36; BookHaven is labelled 36B to include both listed projects.
