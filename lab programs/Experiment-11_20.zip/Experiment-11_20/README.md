# Internet Programming Lab – Experiments 11 to 20

Live webpages (HTML/CSS/JS). Open `index.html` to see all ten projects.

| # | Project | File |
|---|---|---|
| 11 | Home Finder | `Experiment_11_Home_Finder.html` |
| 12 | InsureEasy | `Experiment_12_InsureEasy.html` |
| 13 | BlossomGifts | `Experiment_13_BlossomGifts.html` |
| 14 | ReNewMarket | `Experiment_14_ReNewMarket.html` |
| 15 | EasyToll | `Experiment_15_EasyToll.html` |
| 16 | ComplainEase | `Experiment_16_ComplainEase.html` |
| 17 | VoteOnline | `Experiment_17_VoteOnline.html` |
| 18 | AgriMart | `Experiment_18_AgriMart.html` |
| 19 | VetCare Connect | `Experiment_19_VetCare_Farmer_Doctor.html` |
| 20 | RentRide | `Experiment_20_RentRide.html` |

Demo logins are shown inside each page's Login window (password `pass123`).
Data is stored in the browser (localStorage); no back end is connected.
